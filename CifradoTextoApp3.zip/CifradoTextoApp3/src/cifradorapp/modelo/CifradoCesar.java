package cifradorapp.modelo;

public class CifradoCesar {

    private final int desplazamiento;

    // Constructor: establece el desplazamiento (por defecto 3)
    public CifradoCesar(int desplazamiento) {
        this.desplazamiento = desplazamiento;
    }

    // Método para cifrar texto con el Cifrado César
    public String cifrar(String texto) {
        StringBuilder resultado = new StringBuilder();
        texto = texto.toUpperCase();

        for (int i = 0; i < texto.length(); i++) {
            char caracter = texto.charAt(i);

            if (caracter >= 'A' && caracter <= 'Z') {
                char cifrado = (char) ((caracter - 'A' + desplazamiento) % 26 + 'A');
                resultado.append(cifrado);
            } else {
                resultado.append(caracter);
            }
        }

        return resultado.toString();
    }

    // Método para descifrar texto con el Cifrado César
    public String descifrar(String texto) {
        StringBuilder resultado = new StringBuilder();
        texto = texto.toUpperCase();

        for (int i = 0; i < texto.length(); i++) {
            char caracter = texto.charAt(i);

            if (caracter >= 'A' && caracter <= 'Z') {
                char descifrado = (char) ((caracter - 'A' - desplazamiento + 26) % 26 + 'A');
                resultado.append(descifrado);
            } else {
                resultado.append(caracter);
            }
        }

        return resultado.toString();
    }
}
