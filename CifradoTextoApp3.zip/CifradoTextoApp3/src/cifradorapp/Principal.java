package cifradorapp;

import cifradorapp.vista.VentanaLogin;

public class Principal {
    public static void main(String[] args) {
        // Esta es la clase que se ejecuta al iniciar el programa
        System.out.println("=== Iniciando aplicación de cifrado ===");

        // Si tu aplicación usa interfaz gráfica:
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaLogin().setVisible(true);
            }
        });
    }
}
