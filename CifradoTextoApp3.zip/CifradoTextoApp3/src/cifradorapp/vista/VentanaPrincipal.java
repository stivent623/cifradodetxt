package cifradorapp.vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VentanaPrincipal extends JFrame {

    private final JButton btnCifrar;
    private final JButton btnDescifrar;
    private final JButton btnVerMensajes;
    private final JButton btnCompartir;
    private final JButton btnGuardar;
    private final JButton btnSalir;

    public VentanaPrincipal() {
        setTitle("Panel Principal - Cifrado de Texto");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(6, 1, 10, 10));

        btnCifrar = new JButton("🔐 Cifrar texto");
        btnDescifrar = new JButton("🔓 Descifrar texto");
        btnVerMensajes = new JButton("📜 Textos cifrados");
        btnCompartir = new JButton("📤 Compartir texto");
        btnGuardar = new JButton("💾 Guardar texto");
        btnSalir = new JButton("🚪 Cerrar sesión");

      btnCifrar.addActionListener((ActionEvent e) -> {
          new VentanaCifrado().setVisible(true);
          dispose();
        });


        btnDescifrar.addActionListener((ActionEvent e) -> {
            JOptionPane.showMessageDialog(null, "Abrir ventana de Descifrar texto");
        });

        btnVerMensajes.addActionListener((ActionEvent e) -> {
            JOptionPane.showMessageDialog(null, "Mostrar textos cifrados");
        });

        btnCompartir.addActionListener((ActionEvent e) -> {
            JOptionPane.showMessageDialog(null, "Función para compartir texto");
        });

        btnGuardar.addActionListener((ActionEvent e) -> {
            JOptionPane.showMessageDialog(null, "Texto guardado correctamente");
        });

        btnSalir.addActionListener((ActionEvent e) -> {
            int confirm = JOptionPane.showConfirmDialog(null, "¿Cerrar sesión?", "Salir", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                new VentanaLogin().setVisible(true);
                dispose();
            }
        });

        // Agregar botones
        add(btnCifrar);
        add(btnDescifrar);
        add(btnVerMensajes);
        add(btnCompartir);
        add(btnGuardar);
        add(btnSalir);
    }
}
