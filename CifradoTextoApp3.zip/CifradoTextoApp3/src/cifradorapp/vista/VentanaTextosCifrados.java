package cifradorapp.vista;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;

public class VentanaTextosCifrados extends JFrame {

    private final JTextArea areaTextos;
    private final JButton botonActualizar;
    private final JButton botonCerrar;
    private final File archivoGuardado;

    public VentanaTextosCifrados() {
        setTitle("Textos Cifrados Guardados");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Carpeta donde se guardan los textos cifrados
        String rutaDocumentos = System.getProperty("user.home") + File.separator + "Documents";
        archivoGuardado = new File(rutaDocumentos + File.separator + "textos_cifrados.txt");

        // Área para mostrar el contenido
        areaTextos = new JTextArea();
        areaTextos.setEditable(false);
        areaTextos.setFont(new Font("Consolas", Font.PLAIN, 14));
        JScrollPane scroll = new JScrollPane(areaTextos);

        // Botones
        JPanel panelBotones = new JPanel();
        botonActualizar = new JButton("Actualizar");
        botonCerrar = new JButton("Cerrar");

        panelBotones.add(botonActualizar);
        panelBotones.add(botonCerrar);

        add(scroll, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        // Cargar textos al iniciar
        cargarTextos();

        // Acciones
        botonActualizar.addActionListener((ActionEvent e) -> {
            cargarTextos();
        });

        botonCerrar.addActionListener((ActionEvent e) -> {
            dispose();
        });
    }

    // Método para leer el archivo y mostrar los textos
    private void cargarTextos() {
        areaTextos.setText("");

        if (!archivoGuardado.exists()) {
            areaTextos.setText("No hay textos cifrados guardados aún.");
            return;
        }

        try (BufferedReader lector = new BufferedReader(new FileReader(archivoGuardado))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                areaTextos.append(linea + "\n");
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al leer los textos guardados.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
