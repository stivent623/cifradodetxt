package cifradorapp.vista;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.Base64;
import cifradorapp.modelo.CifradoCesar;

public class VentanaCifrado extends JFrame {

    private JTextArea txtEntrada;
    private JTextArea txtSalida;
    private JButton btnCifrar, btnDescifrar, btnGuardar, btnVolver, btnVerTextos;
    private JComboBox<String> comboCifrado;
    private JLabel lblTitulo;

    public VentanaCifrado() {
        setTitle("Cifrado de Texto - MultiModo");
        setSize(720, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // === Panel superior ===
        JPanel panelSuperior = new JPanel();
        lblTitulo = new JLabel("Centro de Cifrado y Descifrado");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        panelSuperior.add(lblTitulo);

        // === Panel central ===
        JPanel panelCentro = new JPanel(new GridLayout(3, 1, 10, 10));

        comboCifrado = new JComboBox<>(new String[]{
            "Cifrado César",
            "Cifrado Inverso",
            "Cifrado ASCII",
            "Cifrado Base64"
        });

        txtEntrada = new JTextArea("Escribe el texto aquí...");
        txtEntrada.setLineWrap(true);

        txtSalida = new JTextArea();
        txtSalida.setEditable(false);
        txtSalida.setLineWrap(true);

        panelCentro.add(comboCifrado);
        panelCentro.add(new JScrollPane(txtEntrada));
        panelCentro.add(new JScrollPane(txtSalida));

        // === Panel inferior con botones ===
        JPanel panelInferior = new JPanel(new FlowLayout());
        btnCifrar = new JButton("🔐 Cifrar");
        btnDescifrar = new JButton("🔓 Descifrar");
        btnGuardar = new JButton("💾 Guardar");
        btnVerTextos = new JButton("📄 Ver Textos Cifrados");
        btnVolver = new JButton("⬅ Volver");

        panelInferior.add(btnCifrar);
        panelInferior.add(btnDescifrar);
        panelInferior.add(btnGuardar);
        panelInferior.add(btnVerTextos);
        panelInferior.add(btnVolver);

        add(panelSuperior, BorderLayout.NORTH);
        add(panelCentro, BorderLayout.CENTER);
        add(panelInferior, BorderLayout.SOUTH);

        // === Acciones de botones ===
        btnCifrar.addActionListener(e -> {
            String texto = txtEntrada.getText();
            if (texto.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Escribe un texto para cifrar");
                return;
            }
            String metodo = comboCifrado.getSelectedItem().toString();
            String resultado = cifrarTexto(texto, metodo);
            txtSalida.setText(resultado);
        });

        btnDescifrar.addActionListener(e -> {
            String texto = txtEntrada.getText();
            if (texto.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Escribe un texto para descifrar");
                return;
            }
            String metodo = comboCifrado.getSelectedItem().toString();
            String resultado = descifrarTexto(texto, metodo);
            txtSalida.setText(resultado);
        });

        btnGuardar.addActionListener(e -> guardarTextoCifrado());

        btnVerTextos.addActionListener(e -> {
            VentanaTextosCifrados ventana = new VentanaTextosCifrados();
            ventana.setVisible(true);
        });

        btnVolver.addActionListener(e -> {
            new VentanaPrincipal().setVisible(true);
            dispose();
        });
    }

    // ===========================
    // MÉTODOS DE CIFRADO
    // ===========================

    private String cifrarTexto(String texto, String metodo) {
        switch (metodo) {
            case "Cifrado César" -> {
                CifradoCesar cesar = new CifradoCesar(3);
                return cesar.cifrar(texto);
            }
            case "Cifrado Inverso" -> {
                return new StringBuilder(texto).reverse().toString();
            }
            case "Cifrado ASCII" -> {
                StringBuilder ascii = new StringBuilder();
                for (char c : texto.toCharArray()) {
                    ascii.append((int) c).append(" ");
                }
                return ascii.toString().trim();
            }
            case "Cifrado Base64" -> {
                return Base64.getEncoder().encodeToString(texto.getBytes());
            }
            default -> {
                return texto;
            }
        }
    }

    private String descifrarTexto(String texto, String metodo) {
        switch (metodo) {
            case "Cifrado César" -> {
                CifradoCesar cesar = new CifradoCesar(3);
                return cesar.descifrar(texto);
            }
            case "Cifrado Inverso" -> {
                return new StringBuilder(texto).reverse().toString();
            }
            case "Cifrado ASCII" -> {
                String[] partes = texto.split(" ");
                StringBuilder descifrado = new StringBuilder();
                try {
                    for (String parte : partes) {
                        int codigo = Integer.parseInt(parte);
                        descifrado.append((char) codigo);
                    }
                    return descifrado.toString();
                } catch (NumberFormatException e) {
                    return "Error al descifrar texto ASCII.";
                }
            }
            case "Cifrado Base64" -> {
                try {
                    byte[] bytes = Base64.getDecoder().decode(texto);
                    return new String(bytes);
                } catch (Exception e) {
                    return "Error al descifrar Base64.";
                }
            }
            default -> {
                return texto;
            }
        }
    }

    // ===========================
    // MÉTODO PARA GUARDAR ARCHIVO
    // ===========================

    private void guardarTextoCifrado() {
        String texto = txtSalida.getText();
        if (texto.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay texto cifrado para guardar");
            return;
        }

        try {
            // Carpeta “Cifrados” en Documentos
            String userDir = System.getProperty("user.home");
            File carpeta = new File(userDir + File.separator + "Documents" + File.separator + "Cifrados");
            if (!carpeta.exists()) {
                carpeta.mkdirs();
            }

            // Crear archivo
            String nombreArchivo = "cifrado_" + System.currentTimeMillis() + ".txt";
            File archivo = new File(carpeta, nombreArchivo);

            try (FileWriter escritor = new FileWriter(archivo)) {
                escritor.write("Método: " + comboCifrado.getSelectedItem() + "\n\n");
                escritor.write("Texto cifrado:\n" + texto);
            }

            // Guardar también en el historial general
            guardarHistorial(texto);

            JOptionPane.showMessageDialog(null, "Texto guardado en: " + archivo.getAbsolutePath());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar el archivo: " + e.getMessage());
        }
    }

    // ===========================
    // HISTORIAL DE TEXTOS CIFRADOS
    // ===========================

    private void guardarHistorial(String texto) {
        try {
            String ruta = System.getProperty("user.home") + File.separator + "Documents" + File.separator + "textos_cifrados.txt";
            FileWriter writer = new FileWriter(ruta, true);
            writer.write("[" + comboCifrado.getSelectedItem() + "] " + texto + "\n");
            writer.close();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al guardar en historial.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
