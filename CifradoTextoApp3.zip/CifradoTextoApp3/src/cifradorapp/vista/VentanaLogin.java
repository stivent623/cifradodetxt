package cifradorapp.vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VentanaLogin extends JFrame {

    private JTextField campoUsuario;
    private JPasswordField campoContrasena;
    private final JButton botonLogin;

    public VentanaLogin() {
        setTitle("Login - Cifrado de Texto");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(3, 2, 10, 10));

        JLabel lblUsuario = new JLabel("Usuario:");
        campoUsuario = new JTextField();

        JLabel lblContrasena = new JLabel("Contraseña:");
        campoContrasena = new JPasswordField();

        botonLogin = new JButton("Iniciar sesión");

        // Acción del botón
        botonLogin.addActionListener((ActionEvent e) -> {
            String usuario = campoUsuario.getText();
            String clave = new String(campoContrasena.getPassword());
            
            if (usuario.equals("admin") && clave.equals("1234")) {
                JOptionPane.showMessageDialog(null, "Bienvenido " + usuario);
                new VentanaPrincipal().setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos");
            }
        });

        add(lblUsuario);
        add(campoUsuario);
        add(lblContrasena);
        add(campoContrasena);
        add(new JLabel());
        add(botonLogin);
    }
}
